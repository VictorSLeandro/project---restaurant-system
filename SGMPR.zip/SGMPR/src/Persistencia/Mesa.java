

package Persistencia;

public class Mesa {
    
    private int CodigoMesa;
    private int NumMesa;
    private String status;
    /**
     * @return the CodigoMesa
     */
    public int getCodigoMesa() {
        return CodigoMesa;
    }

    /**
     * @param CodigoMesa the CodigoMesa to set
     */
    public void setCodigoMesa(int CodigoMesa) {
        this.CodigoMesa = CodigoMesa;
    }

    /**
     * @return the NumMesa
     */
    public int getNumMesa() {
        return NumMesa;
    }

    /**
     * @param NumMesa the NumMesa to set
     */
    public void setNumMesa(int NumMesa) {
        this.NumMesa = NumMesa;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
    
    
}
